<?php

/**
 * 
 * 
 * @author Konrad
 * @package Management
 */

require_once 'Zend/Db/Table/Abstract.php';

class  Addanddelete_models_formDbParent extends abstract_formDbModelParent {
	/**
	 * The default table name 
	 */
	//protected $_name = 'things';
	
	/*
	public function doInsert($row = null, $data = null, $values = null , $foreignKey = null){
		
		$newRow = parent::doInsert($row, $data, $values, $foreignKey);
			
	}
	*/
}

