<?php

class Components_Entite_View_ViewRelated_library_Exceptions_noOverridingRow extends Exception {

	
}

?>