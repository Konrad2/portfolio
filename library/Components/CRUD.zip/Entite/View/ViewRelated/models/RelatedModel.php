<?php
/**
 * Klasa abstrakcyjna niezbedna do kontrolera dziedziczcedo po abstract_viewController
 *
 * klase nalerzy umiescic w kataogu models o nazwie nazwa moduo+View.php.
 * Jeli chcemy wywietlac  z bazy danych wedlug
 * jakiego� kryterum, nalerzy odpowiednio zmodyfikowa
 * select, następnie je zwr�ci�.
 * @author Konrad
 
 * @package Related
 */

abstract class Components_ViewRelated_models_RelatedModel extends abstract_viewModel {

	
	
	/**
	 * Chc�c wy�wietli� jakie� dane w innym module dostaniemy jaki� wiersz. Akcja viewlabel pobiera klucz 
	 * z kolumny, zdefiniowan� jako foreignKey. Wed�uk tego klucza pobiera wiersz z bazy danych. Nast�pnie wy�wietla skojarzony wiersz. 
	 * 
	 * @var string Klucz obcy wed�ug kturego wyci�gniemy dane z naszej tablicy.
	 */
	
	protected  $foreignKey;
	
	

	
	/**
	 * Chc�c wy�wietli� informacje w innym module modu� musi zna� klucz obcy wed�ug kturego b�dziemy si� odwo�ywa�:
	 * setForeignKey() klucz obcy z innego modu�u.
	 */
	
	public function init(){}
	
	
	/**
	 * @todo ciekawe czy pojeszcze potrzebne.
	 * @param unknown_type $key
	 */
	
	public function setForeignKey( $key ) {

		$this->foreignKey = $key;
	}
	
	
	
	/**
	* S�urzy do wywietlania jaki informacji w innym module. Powi�zane z akcj� showlabel w kontrolerze "View".
	* Aby pobra� dane z tabeli niezb�dne jest zdefiniowanie klucza obcego. Nalerzy w takim wypadku wpisa� atrybut foreignKey za pomoc� metody setForeignKey($ kewy );.
	* @return array Zend_Db_Table_Row 
	* @param Zend_Db_Table_Row $row wiersz tabeli kturego klucz znajduje si� w tabeli tego modelu.
	* @param array nazwy tabel oraz jak maj� si� wy�wietla�.
	*/
	//public function getCustom($row , $rowsName = null)
	
	public function getCustom( $row ) {

		
		$t = $row->toArray();
		
		
		if ( ! isset ( $this->foreignKey ) )
		
			throw new Exception("Nie zdefiniowany klucz obcy");
		

			
		$id = $t [ $this->foreignKey ];
		

	
		$id = $this->getAdapter()->quoteInto('id = ?', $id );

		$r = new Zend_Db_Table_Row();

		$rowsName = $this->customCol();
		
		
		//if( $rowsName != null )	{
			
			
				$select = $this->select();

				$select->from( $this->_moduleName, $rowsName );

				$select->where( $id );

				$r = $this->fetchRow($select);	
			
	//	}
	//	else
		
		//	$r = $this->fetchRow($id);

		return $r;
	}

	
}

?>