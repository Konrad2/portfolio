<?php
/**
 * @package View
 * @author Konrad
 *
 */
interface Pict_interfaces_IpathPictClient {
}

?>