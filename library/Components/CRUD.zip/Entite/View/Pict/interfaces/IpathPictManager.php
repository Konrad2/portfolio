<?php
/**
 * @package View
 * @author Konrad
 *
 */
interface Pict_interfaces_IpathPictManager {
	
	public function setPathToDirectory( $path );
	
	public function getPatchToIconMainPict ( $path );
}

?>