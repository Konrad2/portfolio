<?php

class Abstract_models_viewModel extends Zend_Db_Table {
	
	public function setTableName( $tableName ){
		
		$this->_name = $tableName;
		
	}

}

?>