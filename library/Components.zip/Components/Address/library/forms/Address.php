<?php

class Components_Address_library_forms_Address extends  FormDb_Connect_Parent {
	
	
	public function __construct($options = null) {
		
		parent::__construct($options );
		
		$this->setTableName('address');
		
		$elements = array();		
		$elements[] = new Class_forms_elements_AlphaPl32Req('street',array('label'=>'Ulica'));  		
		$elements[] = new Class_forms_elements_Num5Unsigned ('house_nr',array('label'=>'Numer domu')); 
		$elements[] = new Class_forms_elements_Num5Unsigned ('flat_nr',array('label'=>'Numer lokalu'));
		$elements[] = new Class_forms_elements_AlphaPl16Req('postcode', array('label'=>'Kod Pocztowy'));
		$elements[] = new Class_forms_elements_AlphaPl32Req('city', array('label'=>'Miasto'));
		$elements[] = new Zend_Form_Element_Submit ('Edytuj');  
		$this->addElements ($elements);		
	}
	

}
