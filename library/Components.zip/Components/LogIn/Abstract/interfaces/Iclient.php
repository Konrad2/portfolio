<?php

interface Logx_interfaces_Iclient {
	
	public function setClientData( $data );
	
	public function getClientData();
}

?>