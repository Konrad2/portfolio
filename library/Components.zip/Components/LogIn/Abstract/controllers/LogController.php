<?php

abstract class Abstract_controllers_LogController extends abstract_Controllers_baseController {
	

	abstract public function logAction();
	
	abstract public Function outAction();
	
	//abstract protected function getAuth();
	
}

?>