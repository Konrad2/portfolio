<?php

/** 
 * Forma do logowania
 * @author Konrad 
 * @package Account
 */


abstract class Abstract_library_formLog extends Zend_Form {
	
	
}

?>