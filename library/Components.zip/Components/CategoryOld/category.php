<?php 
/**
 * Aby dodac mduł nalerzy: ?
 */
?>