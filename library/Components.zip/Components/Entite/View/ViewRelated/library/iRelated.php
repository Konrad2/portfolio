<?php
/**
  
 * @author Konrad
 *
 */
interface ViewRelated_library_iRelated {
	
	
	public function viewlabelAction();
	
}

?>