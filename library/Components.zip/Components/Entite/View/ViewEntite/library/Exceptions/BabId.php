<?php

/** 
 * @author Konrad
 * 
 * 
 */
class ViewEntite_library_Exceptions_BabId extends Exception {
	
	
}

?>