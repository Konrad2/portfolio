<?php

class components_createaccount_models_Account extends Zend_Db_Table {
	
	protected $_name = "account";
	
	public function IfLoginExists( $login ){
		
		$select = $this->select();
		$select->where( $this->getAdapter()->quoteInto("login = ?" ,$login) );
	
		return count ($this->fetchRow( $select ) );
	}
	
	public function addUser( array $data){
		echo "dodawanie urzytkowników";
		
		$newRow = $this->createRow($data);
		$newRow->salt = md5( time());
		$newRow->password = md5($newRow->password);
		$newRow->created_at = date('Y-m-d',time());
		$newRow->save();
	}

}

