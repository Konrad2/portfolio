<?php

class FormDb_Connect_models_aConnect extends FormDb_models_Edit {

}

?>